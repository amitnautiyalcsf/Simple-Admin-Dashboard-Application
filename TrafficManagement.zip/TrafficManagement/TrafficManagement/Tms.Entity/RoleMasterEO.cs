﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficManagement.Tms.Entity
{
    class RoleMasterEO
    {
        private String roleName;
        private String roleDesc;


        public string RoleName
        {
            get
            {
                return roleName;
            }

            set
            {
                roleName = value;
            }
        }

        public string RoleDesc
        {
            get
            {
                return roleDesc;
            }

            set
            {
                roleDesc = value;
            }
        }

        public override string ToString()
        {
            return "RoleMasterEO: " + roleName + " " + roleDesc;
        }

    }
}
