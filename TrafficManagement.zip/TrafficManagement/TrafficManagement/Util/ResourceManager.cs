﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Data.SqlClient;

using System.Configuration;

namespace TrafficManagement.Util
{
    class ResourceManager
    {



        public SqlCommand cmd;
        private string connectionString = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

        public ResourceManager()

        {
            try
            {
                using (SqlConnection connection = new SqlConnection(this.connectionString))
                {
                    connection.Open();
                }

            }
            catch (Exception ex)
            {
                //Handle your exeption
            }


        }

    }
}

