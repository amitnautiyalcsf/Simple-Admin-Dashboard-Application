﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrafficManagement.Tms.Entity;
using System.Collections;
using System.Collections.Generic;

namespace TrafficManagement.Tms.DAL
{
    interface RoleMasterDAL
    {
         void addRole(RoleMasterEO roleMasterEORef);
         void removeRole(RoleMasterEO roleMasterEORef);
        void updateRole(RoleMasterEO roleMasterEORef);
         void roleFindByPrimaryKey(string roleName);
        List<RoleMasterEO> findByDynamicSelect(string sql);


    }
}
