﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrafficManagement.Tms.Entity;
using TrafficManagement.View;

namespace TrafficManagement.Tms.DAL.TMS.DALImpl
{
    class RoleMasterDALImpl : RoleMasterDAL
    {
        public void addRole(RoleMasterEO roleMasterEORef)
        {
            throw new NotImplementedException();
     

        }

        public List<RoleMasterEO> findByDynamicSelect(string sql)
        {
            throw new NotImplementedException();
        }

        public void removeRole(RoleMasterEO roleMasterEORef)
        {
            throw new NotImplementedException();
        }

        public void roleFindByPrimaryKey(string roleName)
        {
            throw new NotImplementedException();
        }

        public void updateRole(RoleMasterEO roleMasterEORef)
        {
            throw new NotImplementedException();
        }
    }
}
