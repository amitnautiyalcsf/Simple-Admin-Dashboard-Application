﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrafficManagement.Tms.Entity;

namespace TrafficManagement.Tms.DAL
{
    interface UserMasterDAL
    {
        int addUser(UserMasterEO userMasterEORef);
         void removeUser(UserMasterEO userMasterEORef);
         void updateUser(UserMasterEO userMasterEORef);
       void findUserByPrimaryKey(string userName);

        List<UserMasterEO> findByDynamicSelect(string sql);


    }
}
